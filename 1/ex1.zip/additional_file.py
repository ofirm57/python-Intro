
def secret_function():
    """Defines the secret function"""
    print('My username is ofirm57 and I realize that not checking the '
          'submission response can have consequences for my grade.')