import numpy
import ex8_helper as hl

def random_game(x, y):
    sol = numpy.random.randint(0,2,(x, y))
    c = [[],[]]
    for row in sol:
        c[0].append(hl.get_line_constraints(row))
    for row in sol.transpose():
        c[1].append(hl.get_line_constraints(row))
    return [[-1] * y] * x, sol.tolist(), c