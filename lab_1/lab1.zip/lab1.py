#############################################################
# FILE : lab1.py
# WRITER : ofir malkiely , ofirm57 , 205660731
# EXERCISE : intro2cs2 lab1 2020
# DESCRIPTION: A simple program that prints "Hello World!" to
# the standard output (screen).
#############################################################

print("Hello World!")